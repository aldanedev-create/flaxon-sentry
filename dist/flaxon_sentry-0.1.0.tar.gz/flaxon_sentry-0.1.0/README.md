# Flaxon Sentry Plugin

Sentry error tracking and performance monitoring for Flaxon framework.

## Installation

```bash
pip install flaxon-sentry


Quick Start
python
from flaxon import Flaxon
from flaxon_sentry import SentryPlugin

app = Flaxon("my-app")

# Load Sentry plugin
app.plugins.load_plugin(SentryPlugin(
    dsn="https://your-sentry-dsn",
    environment="production",
    release="1.0.0",
))

@app.get("/")
async def home():
    return {"message": "Hello with Sentry!"}
Features
Error capture — Automatically captures exceptions and sends to Sentry

Request context — Adds request data to Sentry events (method, path, user, etc.)

Performance tracking — Transaction timing for routes

User tracking — Associates errors with users

Custom tags — Add custom tags to events

Ignore patterns — Configure which errors to ignore

Configuration
Environment Variables
bash
export SENTRY_DSN=https://your-sentry-dsn
export SENTRY_ENVIRONMENT=production
export SENTRY_RELEASE=1.0.0
export SENTRY_SAMPLE_RATE=1.0
export SENTRY_TRACES_SAMPLE_RATE=0.1
With Flaxon Config
python
app = Flaxon("my-app", config={
    "SENTRY_DSN": "https://your-sentry-dsn",
    "ENV": "production",
})

plugin = SentryPlugin.from_config(app.config)
app.plugins.load_plugin(plugin)
Advanced Usage
User Context
python
def get_user_from_request(request):
    return {
        "id": request.user.id,
        "email": request.user.email,
        "username": request.user.username,
    }

plugin = SentryPlugin(dsn="...")
plugin.set_user_getter(get_user_from_request)
app.plugins.load_plugin(plugin)
Manual Exception Capture
python
@app.post("/users")
async def create_user(data: CreateUser):
    try:
        # Some operation
        pass
    except Exception as e:
        app.state.sentry_plugin.capture_exception(e, request)
        return {"error": "Failed to create user"}
Adding Breadcrumbs
python
@app.get("/process")
async def process(request):
    app.state.sentry_plugin.add_breadcrumb(
        "Starting process",
        category="process",
        level="info",
        data={"user_id": 123}
    )
    # Process...

License

MIT